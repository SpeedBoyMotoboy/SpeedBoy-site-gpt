# 📋 GUIA: Como colocar o site novo no GitHub
## Speedboy Motoboy — Passo a passo simples

---

## O que está no ZIP

```
speedboy/
├── index.html              ← Página principal (substitui o antigo)
├── empresas.html           ← Página nova para empresas
├── assets/
│   ├── style.css           ← Estilos compartilhados
│   └── main.js             ← JavaScript compartilhado
├── cidades/
│   ├── motoboy-serra-es.html
│   ├── motoboy-vitoria-es.html
│   ├── motoboy-vila-velha-es.html
│   ├── motoboy-cariacica-es.html
│   ├── motoboy-aracruz-es.html
│   ├── motoboy-colatina-es.html
│   └── motoboy-linhares-es.html
└── blog/
    ├── index.html
    ├── quanto-custa-motoboy-serra-es.html
    ├── como-enviar-documentos-cartorio-serra.html
    └── motoboy-empresas-grande-vitoria.html
```

---

## PASSO A PASSO — GitHub pelo navegador (sem instalar nada)

### 1️⃣ Acesse o repositório
- Vá em: https://github.com/speedboymotoboy/speedboy-site
- Faça login se necessário

### 2️⃣ Extraia o ZIP no seu computador
- Clique com botão direito no ZIP baixado
- Escolha "Extrair aqui" ou "Extract Here"
- Vai abrir uma pasta chamada `speedboy`

### 3️⃣ Substitua o index.html
- No GitHub, clique em `index.html`
- Clique no ícone de lápis (✏️ Edit)
- Selecione tudo (Ctrl+A) e apague
- Abra o `index.html` da pasta `speedboy` no Bloco de Notas
- Selecione tudo (Ctrl+A), copie (Ctrl+C)
- Cole no GitHub (Ctrl+V)
- Role até o fim e clique em **"Commit changes"**

### 4️⃣ Crie a pasta `assets`
- Na página principal do repositório, clique em **"Add file"** → **"Create new file"**
- No nome do arquivo, digite: `assets/style.css`
- Abra o arquivo `assets/style.css` da pasta `speedboy` no Bloco de Notas
- Copie e cole o conteúdo
- Clique em **"Commit changes"**
- Repita para `assets/main.js`

### 5️⃣ Crie a pasta `cidades` e suba os arquivos
- Clique em **"Add file"** → **"Create new file"**
- Nome: `cidades/motoboy-serra-es.html`
- Cole o conteúdo do arquivo correspondente
- Repita para cada cidade (são 7 arquivos)

### 6️⃣ Crie a pasta `blog`
- Mesmo processo: **"Add file"** → **"Create new file"**
- Nome: `blog/index.html` → cole o conteúdo
- Repita para os 3 artigos do blog

### 7️⃣ Suba o `empresas.html`
- **"Add file"** → **"Create new file"**
- Nome: `empresas.html`
- Cole o conteúdo

---

## ✅ Checklist final

- [ ] `index.html` substituído
- [ ] `assets/style.css` criado
- [ ] `assets/main.js` criado
- [ ] `empresas.html` criado
- [ ] 7 páginas de cidades criadas
- [ ] `blog/index.html` criado
- [ ] 3 artigos do blog criados

---

## 🔧 Próximos passos recomendados (faça depois)

1. **Google Meu Negócio** → acesse business.google.com e preencha tudo com fotos e horários
2. **Google Search Console** → acesse search.google.com/search-console e cadastre o site
3. **Meta Pixel** → crie em business.facebook.com e insira o código no `<head>` do index.html

---

## ❓ Dúvidas?

Entre em contato pelo WhatsApp e peço ajuda:
Ligue: +55 27 99916-5959
